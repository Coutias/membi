====="How to change UUID and Serial of Motherboard tutorial for Se7ensins"=====
1. Run DMIEDIT as Admin
2. Change UUID: System Information->UUID (Double click and change to whatever but keep the same length 32 digits)
3. Change Serial: Base Board->Serial Number (Double click and change to whatever but keep the same length)
4. After that just hit Update->All

If you get any errors relating to PNP your motherboard isn't compatible with this version of dmiEdit.